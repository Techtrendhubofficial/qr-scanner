import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { TechTrendStore } from './components/TechTrendStore';
import { NexusNotepad } from './components/NexusNotepad';
import { Scanner } from './components/Scanner';
import { AlbumScanner } from './components/AlbumScanner';
import { Generator } from './components/Generator';
import { History } from './components/History';
import { AuditReportModal } from './components/AuditReportModal';
import { PlayStoreModal } from './components/PlayStoreModal';
import { VipModal } from './components/VipModal';
import { GoogleAuditHelperModal } from './components/GoogleAuditHelperModal';
import { HostingMigrationModal } from './components/HostingMigrationModal';
import { TabType, ScanItem, GeneratedQrItem } from './types';
import { Language } from './utils/i18n';

export const App: React.FC = () => {
  // Language State (Defaults to English 'en' for Google Play and global users, with easy toggle to Chinese)
  const [lang, setLang] = useState<Language>(() => {
    const saved = localStorage.getItem('pavilion_app_lang');
    if (saved === 'en' || saved === 'zh') return saved;
    return 'en';
  });

  const toggleLang = () => {
    setLang((prev) => {
      const next: Language = prev === 'en' ? 'zh' : 'en';
      localStorage.setItem('pavilion_app_lang', next);
      return next;
    });
  };

  // Check if current hostname is dedicated shop domain (e.g. shop.pavilionventure.com) or query/path mode
  const isDedicatedShop = typeof window !== 'undefined' && (
    window.location.hostname.toLowerCase().startsWith('shop.') ||
    window.location.hostname.toLowerCase().includes('store') ||
    window.location.pathname.toLowerCase().startsWith('/shop') ||
    window.location.pathname.toLowerCase().startsWith('/s/') ||
    window.location.pathname.toLowerCase().startsWith('/product') ||
    window.location.search.includes('mode=shop') ||
    window.location.search.includes('view=store')
  );

  // Default to Store view, with path and query parameter routing support
  const [activeTab, setActiveTab] = useState<TabType>(() => {
    if (typeof window !== 'undefined') {
      const host = window.location.hostname.toLowerCase();
      if (host.startsWith('shop.') || host.includes('store')) return 'store';
      const url = new URL(window.location.href);
      const tabParam = url.searchParams.get('tab');
      if (tabParam === 'scan') return 'scan';
      if (tabParam === 'store' || tabParam === 'shop') return 'store';
      const path = window.location.pathname.toLowerCase();
      if (path.includes('shop') || path.includes('product') || path.includes('store')) return 'store';
    }
    return 'scan';
  });
  
  // Modals
  const [isAuditModalOpen, setIsAuditModalOpen] = useState(false);
  const [isPlayStoreModalOpen, setIsPlayStoreModalOpen] = useState(false);
  const [isVipModalOpen, setIsVipModalOpen] = useState(false);
  const [isGoogleHelperModalOpen, setIsGoogleHelperModalOpen] = useState(false);
  const [isHostingModalOpen, setIsHostingModalOpen] = useState(false);

  // VIP Status
  const [isVip, setIsVip] = useState<boolean>(() => {
    return localStorage.getItem('pavilion_vip_active') === 'true';
  });


  const handleSetVip = (val: boolean) => {
    setIsVip(val);
    localStorage.setItem('pavilion_vip_active', val ? 'true' : 'false');
  };

  // Scans History
  const [scans, setScans] = useState<ScanItem[]>(() => {
    try {
      const saved = localStorage.getItem('pavilion_scans_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Generations History
  const [generations, setGenerations] = useState<GeneratedQrItem[]>(() => {
    try {
      const saved = localStorage.getItem('pavilion_gens_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Save history to localStorage
  useEffect(() => {
    localStorage.setItem('pavilion_scans_history', JSON.stringify(scans));
  }, [scans]);

  useEffect(() => {
    localStorage.setItem('pavilion_gens_history', JSON.stringify(generations));
  }, [generations]);

  const handleScanResult = (result: ScanItem) => {
    setScans((prev) => [result, ...prev]);
  };

  const handleSaveQr = (item: GeneratedQrItem) => {
    setGenerations((prev) => [item, ...prev]);
  };

  const handleClearHistory = () => {
    if (window.confirm('确定要清空全部本地历史记录吗？此操作无法撤销。')) {
      setScans([]);
      setGenerations([]);
      localStorage.removeItem('pavilion_scans_history');
      localStorage.removeItem('pavilion_gens_history');
    }
  };

  // If accessed directly from shop.pavilionventure.com or ?mode=shop, render pure flagship store
  if (isDedicatedShop) {
    return (
      <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col font-sans">
        <main className="flex-1 flex flex-col">
          <TechTrendStore onSwitchToNotepad={() => {}} />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col font-sans">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        openAuditModal={() => setIsAuditModalOpen(true)}
        openPlayStoreModal={() => setIsPlayStoreModalOpen(true)}
        openGoogleHelperModal={() => setIsGoogleHelperModalOpen(true)}
        openHostingModal={() => setIsHostingModalOpen(true)}
        openVipModal={() => setIsVipModalOpen(true)}
        isVip={isVip}
        lang={lang}
        toggleLang={toggleLang}
      />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col">
        {activeTab === 'store' && (
          <TechTrendStore onSwitchToNotepad={() => setActiveTab('notepad')} />
        )}

        {activeTab === 'notepad' && (
          <NexusNotepad />
        )}

        {activeTab === 'scan' && (
          <Scanner
            onScanResult={handleScanResult}
            onOpenAlbum={() => setActiveTab('album')}
            lang={lang}
          />
        )}

        {activeTab === 'album' && (
          <AlbumScanner onScanResult={handleScanResult} />
        )}

        {activeTab === 'generate' && (
          <Generator onSaveQr={handleSaveQr} />
        )}

        {activeTab === 'history' && (
          <History
            scans={scans}
            generations={generations}
            onClearHistory={handleClearHistory}
          />
        )}
      </main>

      {/* Bottom Navigation for Mobile */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        openVipModal={() => setIsVipModalOpen(true)}
        isVip={isVip}
        lang={lang}
      />


      {/* Modals */}
      <AuditReportModal
        isOpen={isAuditModalOpen}
        onClose={() => setIsAuditModalOpen(false)}
      />

      <PlayStoreModal
        isOpen={isPlayStoreModalOpen}
        onClose={() => setIsPlayStoreModalOpen(false)}
      />

      <GoogleAuditHelperModal
        isOpen={isGoogleHelperModalOpen}
        onClose={() => setIsGoogleHelperModalOpen(false)}
      />

      <HostingMigrationModal
        isOpen={isHostingModalOpen}
        onClose={() => setIsHostingModalOpen(false)}
      />

      <VipModal
        isOpen={isVipModalOpen}
        onClose={() => setIsVipModalOpen(false)}
        isVip={isVip}
        setIsVip={handleSetVip}
      />
    </div>
  );
};

export default App;
